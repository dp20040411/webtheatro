<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'online_registration';

// Establish a connection to the MySQL database
$conn = mysqli_connect($host, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


?>
