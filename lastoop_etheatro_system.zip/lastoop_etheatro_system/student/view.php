<?php
require '../includes/db.php';

$search_id = '';
$status_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $search_id = trim($_POST['search_id']);
    $search_id = htmlspecialchars($search_id);

    if (!empty($search_id)) {
        // Step 1: Try to find user_id using school_id from any of the tables
        $user_id = null;

        $tables = ['applicants', 'rejected_applications', 'pending_applications'];
        foreach ($tables as $table) {
            $stmt = $conn->prepare("SELECT user_id FROM $table WHERE school_id = ?");
            if (!$stmt) {
                die("Prepare failed in $table: " . $conn->error);
            }
            $stmt->bind_param('s', $search_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $user = $result->fetch_assoc();
                $user_id = $user['user_id'];
                break;
            }
        }

        if ($user_id !== null) {
            // Check if approved
            $stmt = $conn->prepare("SELECT * FROM applicants WHERE user_id = ?");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $approved = $stmt->get_result();

            if ($approved->num_rows > 0) {
                $status_message = '✅ Congratulations! Your Audition Request has been approved by the ADMIN.';
            } else {
                // Check if rejected
                $stmt = $conn->prepare("SELECT * FROM rejected_applications WHERE user_id = ?");
                $stmt->bind_param('i', $user_id);
                $stmt->execute();
                $rejected = $stmt->get_result();

                if ($rejected->num_rows > 0) {
                    $status_message = '❌ We regret to inform you that your Audition Request has been rejected by the ADMIN.';
                } else {
                    // Check if still pending
                    $stmt = $conn->prepare("SELECT * FROM pending_applications WHERE user_id = ?");
                    $stmt->bind_param('i', $user_id);
                    $stmt->execute();
                    $pending = $stmt->get_result();

                    if ($pending->num_rows > 0) {
                        $status_message = '⌛ Your Audition Request is still under review. Please check back later.';
                    } else {
                        $status_message = '⚠️ No audition request was found for this ID.';
                    }
                }
            }
        } else {
            $status_message = '⚠️ No record found with that School ID.';
        }
    } else {
        $status_message = '⚠️ Please enter your School ID.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cosmic Audition Request Status</title>
    <link rel="stylesheet" href="../design/view.css">
</head>
<body>
    <div class="galaxy"></div>
    <div class="container">
        <h1>Check Audition Request Status</h1>

        <form method="POST">
            <div class="search-wrapper">
                <input type="text" 
                       name="search_id" 
                       class="search-input" 
                       placeholder="Enter your School ID"
                       value="<?= htmlspecialchars($search_id) ?>" 
                       required>
                <div class="cosmic-effects">
                    <div class="cosmic-layer stardust"></div>
                    <div class="cosmic-layer cosmic-ring"></div>
                    <div class="cosmic-layer nebula"></div>
                </div>
                <div class="glow"></div>
            </div>

            <button type="submit" class="button">Search</button>

            <?php if ($status_message): ?>
                <div class="status 
                    <?= strpos($status_message, 'approved') !== false ? 'success' : 
                       (strpos($status_message, 'review') !== false ? 'pending' : 'error') ?>">
                    <?= $status_message ?>
                </div>
            <?php endif; ?>

            <button type="button" class="button back-button" onclick="window.location.href='../index.php'">Back</button>
        </form>
    </div>

    <script>
        const searchWrapper = document.querySelector('.search-wrapper');
        const glow = document.querySelector('.glow');

        searchWrapper.addEventListener('mousemove', (e) => {
            const rect = searchWrapper.getBoundingClientRect();
            const x = e.clientX - rect.left - 20;
            const y = e.clientY - rect.top - 15;
            glow.style.transform = `translate(${x}px, ${y}px)`;
        });

        document.querySelector('.search-input').addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html>
