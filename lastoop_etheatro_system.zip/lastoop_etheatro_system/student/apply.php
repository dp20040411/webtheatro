<?php
session_start();
include '../includes/db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$errorMessage = '';
$successMessage = '';

// Helper: Fetch ID or insert new value if not found
function getIdOrInsert($conn, $table, $column, $value) {
    $query = "SELECT * FROM $table WHERE $column = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $value);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if ($row) return $row[array_key_first($row)];

    $insert = $conn->prepare("INSERT INTO $table ($column) VALUES (?)");
    $insert->bind_param("s", $value);
    if ($insert->execute()) {
        $id = $insert->insert_id;
        $insert->close();
        return $id;
    }

    return null;
}

// Helper: Get or insert user
function getUserIdOrInsert($conn, $email) {
    $query = "SELECT user_id FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($user_id);
    if ($stmt->fetch()) {
        $stmt->close();
        return $user_id;
    }
    $stmt->close();

    // Default password (you should replace this with a random password and send it securely)
    $default_password = password_hash("default123", PASSWORD_DEFAULT);
    $insert = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
    $insert->bind_param("ss", $email, $default_password);
    if ($insert->execute()) {
        $id = $insert->insert_id;
        $insert->close();
        return $id;
    }

    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $school_id   = trim($_POST['school_id']);
    $first_name  = trim($_POST['first_name']);
    $middle_init = trim($_POST['middle_initial']);
    $last_name   = trim($_POST['last_name']);
    $year_label  = trim($_POST['year_level']);
    $dept_name   = trim($_POST['department']);
    $talent_name = trim($_POST['talent']);
    $email       = trim($_POST['email']);

    // Resolve or insert lookup values
    $year_id   = getIdOrInsert($conn, 'year_levels', 'year_label', $year_label);
    $dept_id   = getIdOrInsert($conn, 'departments', 'dept_name', $dept_name);
    $talent_id = getIdOrInsert($conn, 'talents', 'talent_name', $talent_name);

    if (!$year_id || !$dept_id || !$talent_id) {
        $errorMessage = "Invalid Year Level, Department, or Talent.";
    } else {
        // Check for existing email across all application tables
        $check_email_sql = "
            SELECT email FROM pending_applications WHERE email = ?
            UNION
            SELECT email FROM applicants WHERE email = ?
            UNION
            SELECT email FROM rejected_applications WHERE email = ?
        ";
        $stmt = $conn->prepare($check_email_sql);
        $stmt->bind_param("sss", $email, $email, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errorMessage = "This email is already registered or was already processed.";
        } else {
            // Get or insert user into users table
            $user_id = getUserIdOrInsert($conn, $email);

            if (!$user_id) {
                $errorMessage = "Failed to create user record.";
            } else {
                // Insert into pending_applications
                $insert_sql = "INSERT INTO pending_applications 
                    (user_id, school_id, first_name, middle_initial, last_name, year_id, dept_id, talent_id, email) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

                $stmt = $conn->prepare($insert_sql);
                $stmt->bind_param("issssiiis", $user_id, $school_id, $first_name, $middle_init, $last_name, $year_id, $dept_id, $talent_id, $email);

                if ($stmt->execute()) {
                    $successMessage = "Application submitted successfully. Please await admin review.";
                } else {
                    $errorMessage = "Error submitting application: " . $stmt->error;
                }
            }
        }
        $stmt->close();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Application Form</title>
    <link rel="stylesheet" href="../design/apply.css">
</head>
<body>
    <header>Application Form</header>

    <?php if ($errorMessage): ?>
        <div class="error-message"><?= htmlspecialchars($errorMessage) ?></div>
    <?php elseif ($successMessage): ?>
        <div class="success-message"><?= htmlspecialchars($successMessage) ?></div>
    <?php endif; ?>

    <form action="" method="POST">
        <label for="school_id">School ID:</label>
        <input type="text" id="school_id" name="school_id" required>

        <label for="first_name">First Name:</label>
        <input type="text" id="first_name" name="first_name" required>

        <label for="middle_initial">Middle Initial:</label>
        <input type="text" id="middle_initial" name="middle_initial" maxlength="1">

        <label for="last_name">Last Name:</label>
        <input type="text" id="last_name" name="last_name" required>

        <label for="year_level">Year Level:</label>
        <select id="year_level" name="year_level" required>
            <option value="">Select Year Level</option>
            <option value="1st Year">1st Year</option>
            <option value="2nd Year">2nd Year</option>
            <option value="3rd Year">3rd Year</option>
            <option value="4th Year">4th Year</option>
        </select>

        <label for="department">Department:</label>
        <select id="department" name="department" required>
            <option value="">Select Department</option>
            <option value="IT">IT</option>
            <option value="EDUC">EDUC</option>
            <option value="MB">MB</option>
        </select>

        <label for="talent">Talent:</label>
        <input type="text" id="talent" name="talent" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <div class="button-container">
            <button type="submit">Submit</button>
            <button type="button" class="back-button" onclick="window.location.href='../index.php';">Back</button>
        </div>
    </form>
</body>
</html>
