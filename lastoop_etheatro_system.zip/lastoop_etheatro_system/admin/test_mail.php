<?php
require '../includes/mailer.php';

if (sendNotificationEmail('testrecipient@example.com', 'Test Email', 'This is a test email from ETHEATRO')) {
    echo "Email sent successfully!";
} else {
    echo "Failed to send email. Check logs.";
}
