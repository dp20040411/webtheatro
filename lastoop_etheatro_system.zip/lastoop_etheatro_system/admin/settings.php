<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            flex-direction: column; /* Stack buttons vertically */
            justify-content: center;
            align-items: center;
            font-family: 'Inter', Arial, sans-serif;

            /* Background image styles */
            background-image: url('etheatro.jpg'); /* Replace with your image file name or path */
            background-size: center;
            background-position: center;
            background-repeat: no-repeat;
            position: relative;
            z-index: 0;
        }

        /* Overlay */
        body::before {
            content: "";
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.4); /* Slightly darker overlay for better visibility */
            z-index: -1;
        }

        .button {
            text-decoration: none;
            background-color: rgba(255, 255, 255, 0.9); /* More opaque white for better contrast */
            color:rgb(59, 100, 141);
            padding: 16px 32px;
            font-size: 1.25rem;
            border-radius: 50px;
            box-shadow: 0 8px 15px rgba(44, 62, 80, 0.25);
            transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.2s ease;
            font-weight: 500;
            user-select: none;
            position: relative;
            z-index: 1;
            margin: 10px; /* Add margin for spacing between buttons */
        }

        .button:hover,
        .button:focus {
            background-color: rgba(1, 1, 1, 0.9); /* Slightly transparent on hover */
            box-shadow: 0 12px 20px rgba(44, 62, 80, 0.4);
            transform: translateY(-3px);
            outline: none;
        }

        .button:active {
            transform: translateY(-1px);
            box-shadow: 0 6px 8px rgba(44, 62, 80, 0.2);
        }

        @media (max-width: 400px) {
            .button {
                padding: 14px 24px;
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <a href="add_member.php" class="button">Insert Member</a>
    <a href="dashboard.php" class="button">Back</a> <!-- Back button added -->
</body>
</html>
