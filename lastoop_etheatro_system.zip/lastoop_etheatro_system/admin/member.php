<?php
session_start();
require '../includes/db.php';

if (empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Handle member removal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_member'])) {
    $memberId = intval($_POST['member_id']);

    // Step 1: Get user_id from applicants
    $stmt = $conn->prepare("SELECT user_id FROM applicants WHERE applicant_id = ?");
    $stmt->bind_param("i", $memberId);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();

    if ($user_id) {
        // Step 2: Delete from users (cascades to all related data)
        $deleteUser = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $deleteUser->bind_param("i", $user_id);
        if ($deleteUser->execute()) {
            $_SESSION['remove_success'] = "✅ Member and all related records removed.";

            // Step 3: Clean up unused reference data
            $conn->query("
                DELETE FROM talents 
                WHERE talent_id NOT IN (
                    SELECT talent_id FROM applicants
                    UNION
                    SELECT talent_id FROM pending_applications
                    UNION
                    SELECT talent_id FROM rejected_applications
                )
            ");
            $conn->query("
                DELETE FROM year_levels 
                WHERE year_id NOT IN (
                    SELECT year_id FROM applicants
                    UNION
                    SELECT year_id FROM pending_applications
                    UNION
                    SELECT year_id FROM rejected_applications
                )
            ");
            $conn->query("
                DELETE FROM departments 
                WHERE dept_id NOT IN (
                    SELECT dept_id FROM applicants
                    UNION
                    SELECT dept_id FROM pending_applications
                    UNION
                    SELECT dept_id FROM rejected_applications
                )
            ");
        } else {
            $_SESSION['remove_success'] = "❌ Failed to delete user.";
        }
        $deleteUser->close();
    } else {
        $_SESSION['remove_success'] = "⚠️ Member not found.";
    }

    header("Location: dashboard.php");
    exit;
}

// Fetch approved applicants
$sql = "
    SELECT 
        a.applicant_id, a.school_id, a.first_name, a.middle_initial, a.last_name, a.email,
        y.year_label, d.dept_name, t.talent_name
    FROM applicants a
    JOIN year_levels y ON a.year_id = y.year_id
    JOIN departments d ON a.dept_id = d.dept_id
    JOIN talents t ON a.talent_id = t.talent_id
";
$result = $conn->query($sql);
if (!$result) {
    die("Query Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Approved Members</title>
    <link rel="stylesheet" href="../design/members.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #1e3a8a;
        }
        .back-button {
            display: inline-block;
            margin: 10px 0;
            padding: 10px 15px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ccc;
            padding: 12px;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
        }
        button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>

<h1>Approved Members</h1>
<a href="dashboard.php" class="back-button">Back to Dashboard</a>

<?php if (!empty($_SESSION['remove_success'])): ?>
    <script>
        alert("<?= addslashes($_SESSION['remove_success']); ?>");
    </script>
    <?php unset($_SESSION['remove_success']); ?>
<?php endif; ?>

<?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>School ID</th>
                <th>Name</th>
                <th>Year Level</th>
                <th>Department</th>
                <th>Talent</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['applicant_id']) ?></td>
                    <td><?= htmlspecialchars($row['school_id']) ?></td>
                    <td><?= htmlspecialchars($row['first_name'] . ' ' . $row['middle_initial'] . ' ' . $row['last_name']) ?></td>
                    <td><?= htmlspecialchars($row['year_label']) ?></td>
                    <td><?= htmlspecialchars($row['dept_name']) ?></td>
                    <td><?= htmlspecialchars($row['talent_name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Are you sure you want to remove this member?');">
                            <input type="hidden" name="member_id" value="<?= $row['applicant_id'] ?>">
                            <button type="submit" name="remove_member">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No approved members found.</p>
<?php endif; ?>

</body>
</html>
