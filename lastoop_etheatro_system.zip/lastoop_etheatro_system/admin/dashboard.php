<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Not logged in, redirect to login page
    header('Location: login.php');
    exit;
}

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>Welcome Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
    <style>
        /* Reset defaults */
        *, *::before, *::after {
            box-sizing: border-box;
        }
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            overflow: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .container-fluid {
            display: flex;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }

        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            padding: 20px 15px;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
            box-sizing: border-box;
            z-index: 1000;
            height: 100vh;
        }

        .sidebar-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 1px solid #495057;
            padding-bottom: 10px;
        }

        .sidebar-header h3 {
            margin: 0;
            font-weight: 700;
            font-size: 1.8rem;
            letter-spacing: 2px;
        }

        .nav {
            list-style: none;
            padding-left: 0;
            margin: 0;
            flex-grow: 1;
            overflow-y: auto;
        }

        .nav-item {
            margin-bottom: 15px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            font-size: 1rem;
            padding: 10px 12px;
            border-radius: 6px;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }

        .nav-link i {
            min-width: 20px;
            margin-right: 12px;
            font-size: 1.2rem;
        }

        .nav-link:hover {
            background-color: #495057;
            color: #ffffff;
        }

        .nav-link.active {
            background-color: #007bff;
            color: white;
        }

        .logout-btn .nav-link {
            background-color: #dc3545;
            font-weight: 600;
            margin-top: auto;
            justify-content: flex-start;
        }

        .logout-btn .nav-link:hover {
            background-color: #c82333;
        }

        .main-content {
            flex-grow: 1;
            background-color: white;
            padding: 32px 40px;
            overflow-y: auto;
            box-sizing: border-box;
            height: 100vh;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 24px;
            text-align: center;
        }

        .main-content h2 {
            margin: 0;
            font-weight: 700;
            font-size: 1.8rem;
        }

        .logo-container {
            width: 160px;
            height: 160px;
            position: relative;
            animation: pulse 3s ease-in-out infinite;
        }

        .logo-container img {
            max-width: 100%;
            height: auto;
            display: block;
            border-radius: 50%;
            box-shadow: 0 0 15px rgba(0,123,255,0.7);
            transition: transform 0.3s ease;
        }

        .logo-container:hover img {
            transform: scale(1.1) rotate(10deg);
            box-shadow: 0 0 25px rgba(0,123,255,1);
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
                box-shadow: 0 0 15px rgba(0,123,255,0.7);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 0 25px rgba(0,123,255,1);
            }
        }

        .sidebar-toggle-btn {
            display: none;
            position: fixed;
            top: 12px;
            left: 12px;
            background-color: #007bff;
            border: none;
            color: white;
            padding: 10px 14px;
            font-size: 1.2rem;
            border-radius: 6px;
            cursor: pointer;
            z-index: 1100;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }

        .sidebar-toggle-btn:hover {
            background-color: #0056b3;
        }

        @media (max-width: 600px) {
            body, html {
                overflow: hidden;
            }
            .container-fluid {
                flex-direction: column;
                height: 100vh;
                width: 100vw;
            }

            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                height: 100vh;
                width: 250px;
                transform: translateX(-100%);
                box-shadow: 2px 0 12px rgba(0,0,0,0.4);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                padding: 16px 20px;
                height: 100vh;
                overflow-y: auto;
            }

            .sidebar-toggle-btn {
                display: block;
            }
        }
    </style>
</head>
<body>
    <button class="sidebar-toggle-btn" aria-label="Toggle sidebar" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-bars"></i>
    </button>
    <div class="container-fluid">
        <nav class="sidebar" role="navigation" aria-label="Sidebar navigation">
            <div class="sidebar-header">
                <h3>Welcome Admin</h3>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="view_request.php">
                        <i class="fas fa-tasks"></i> <span>View Request</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="member.php">
                        <i class="fas fa-users"></i> <span>List of Members</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php">
                        <i class="fas fa-cog"></i> <span>Settings</span>
                    </a>
                </li>
                <li class="nav-item logout-btn">
                    <a class="nav-link" href="../includes/logout.php" id="logout-link">
                        <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                    </a>
                </li>
            </ul>
        </nav>

        <main class="main-content" role="main" aria-label="Admin Dashboard">
            <h2>Admin Dashboard</h2>

            <!-- Animated logo -->
            <div class="logo-container" aria-label="Animated logo">
                <img src="etheatro.jpg" alt="iConnect Logo" />
            </div>

            
        </main>
    </div>

    <script>
        const toggleBtn = document.querySelector('.sidebar-toggle-btn');
        const sidebar = document.querySelector('.sidebar');

        toggleBtn.addEventListener('click', () => {
            const isOpen = sidebar.classList.toggle('open');
            toggleBtn.setAttribute('aria-expanded', isOpen);
        });

        document.addEventListener('click', (event) => {
            if(window.innerWidth <= 600) {
                if (!sidebar.contains(event.target) && !toggleBtn.contains(event.target) && sidebar.classList.contains('open')) {
                    sidebar.classList.remove('open');
                    toggleBtn.setAttribute('aria-expanded', false);
                }
            }
        });
    </script>
</body>
</html>
