<?php
session_start();

// Hardcoded admin credentials
define('ADMIN_EMAIL', 'admin@gmail.com');
define('ADMIN_PASSWORD', 'admin123');

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($email === ADMIN_EMAIL && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_email'] = $email;
        header('Location: dashboard.php');
        exit;
    } else {
        $errorMessage = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
    <link rel="stylesheet" href="../design/login.css">
</head>
<body>

<div class="login-container">
    <img src="etheatro.jpg" alt="ETHEATRO Logo" class="logo">
    <h2>Admin Login</h2>

    <form method="POST" onsubmit="return confirmLogin();">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="password">Password:</label>
        <div class="password-wrapper">
            <input type="password" id="adminPasswordInput" name="password" required>
            <i class="fas fa-eye toggle-password" id="eyeIcon" onclick="togglePassword()"></i>
        </div>

        <input type="submit" value="Login" class="btn">
    </form>

    <button class="back-btn btn" onclick="window.location.href='../index.php';">⬅ Back</button>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>
</div>

<script>
    function confirmLogin() {
        return confirm("Are you sure you want to log in as admin?");
    }

    function togglePassword() {
        const input = document.getElementById("adminPasswordInput");
        const icon = document.getElementById("eyeIcon");
        if (input.type === "password") {
            input.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        } else {
            input.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        }
    }
</script>

</body>
</html>
