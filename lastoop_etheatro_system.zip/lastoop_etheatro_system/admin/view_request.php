<?php
session_start();
require '../includes/db.php';
require '../includes/mailer.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$message = '';

// Handle form action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pending_id'], $_POST['action'])) {
    $pending_id = (int)$_POST['pending_id'];
    $action = $_POST['action'];

    $stmt = $conn->prepare("SELECT * FROM pending_applications WHERE pending_id = ?");
    $stmt->bind_param('i', $pending_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $applicant = $result->fetch_assoc();
    $stmt->close();

    if ($applicant) {
        $full_name = $applicant['first_name'] . ' ' . $applicant['middle_initial'] . ' ' . $applicant['last_name'];

        if ($action === 'approve') {
            $stmt = $conn->prepare("
                INSERT INTO applicants 
                (user_id, school_id, first_name, middle_initial, last_name, year_id, dept_id, talent_id, email)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                'issssiiis',
                $applicant['user_id'],
                $applicant['school_id'],
                $applicant['first_name'],
                $applicant['middle_initial'],
                $applicant['last_name'],
                $applicant['year_id'],
                $applicant['dept_id'],
                $applicant['talent_id'],
                $applicant['email']
            );

            if ($stmt->execute()) {
                $delete = $conn->prepare("DELETE FROM pending_applications WHERE pending_id = ?");
                $delete->bind_param('i', $pending_id);
                $delete->execute();
                $delete->close();

                $subject = '🎉 Your Audition is Approved!';
                $body = "Hi $full_name,\n\nYour audition request has been approved!\n\nThank you for joining ETHEATRO.\n\n— ETHEATRO Team";
                sendNotificationEmail($applicant['email'], $subject, $body);

                $message = "Applicant approved and notified.";
            } else {
                $message = "Error approving applicant.";
            }

            $stmt->close();

        } elseif ($action === 'reject') {
            $stmt = $conn->prepare("
                INSERT INTO rejected_applications 
                (user_id, school_id, first_name, middle_initial, last_name, year_id, dept_id, talent_id, email)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                'issssiiis',
                $applicant['user_id'],
                $applicant['school_id'],
                $applicant['first_name'],
                $applicant['middle_initial'],
                $applicant['last_name'],
                $applicant['year_id'],
                $applicant['dept_id'],
                $applicant['talent_id'],
                $applicant['email']
            );

            if ($stmt->execute()) {
                $delete = $conn->prepare("DELETE FROM pending_applications WHERE pending_id = ?");
                $delete->bind_param('i', $pending_id);
                $delete->execute();
                $delete->close();

                $subject = '❌ Your Audition was Not Accepted';
                $body = "Hi $full_name,\n\nWe regret to inform you that your audition request has been rejected.\n\nWe appreciate your interest and encourage you to apply again in the future.\n\n— ETHEATRO Team";
                sendNotificationEmail($applicant['email'], $subject, $body);

                $message = "Applicant rejected and notified.";
            } else {
                $message = "Error rejecting applicant.";
            }

            $stmt->close();
        } else {
            $message = "Invalid action.";
        }
    } else {
        $message = "Applicant not found.";
    }
}

// Fetch pending applicants
$result = $conn->query("
    SELECT 
        p.pending_id, p.school_id, p.first_name, p.middle_initial, p.last_name,
        y.year_label, d.dept_name, t.talent_name, p.email
    FROM pending_applications p
    JOIN year_levels y ON p.year_id = y.year_id
    JOIN departments d ON p.dept_id = d.dept_id
    JOIN talents t ON p.talent_id = t.talent_id
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Pending Applications</title>
    <link rel="stylesheet" href="../design/view_request.css">
</head>
<body>
    <h1>Pending Applications</h1>

    <?php if (!empty($message)): ?>
        <p class="notification"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <a href="dashboard.php" class="back-button">Back to Dashboard</a>

    <?php if ($result && $result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>School ID</th>
                    <th>Full Name</th>
                    <th>Year Level</th>
                    <th>Department</th>
                    <th>Talent</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['pending_id']) ?></td>
                        <td><?= htmlspecialchars($row['school_id']) ?></td>
                        <td><?= htmlspecialchars($row['first_name']) ?> <?= htmlspecialchars($row['middle_initial']) ?> <?= htmlspecialchars($row['last_name']) ?></td>
                        <td><?= htmlspecialchars($row['year_label']) ?></td>
                        <td><?= htmlspecialchars($row['dept_name']) ?></td>
                        <td><?= htmlspecialchars($row['talent_name']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="pending_id" value="<?= $row['pending_id'] ?>">
                                <button type="submit" name="action" value="approve" onclick="return confirm('Are you sure you want to approve this applicant?')">Approve</button>
                                <button type="submit" name="action" value="reject" onclick="return confirm('Are you sure you want to reject this applicant?')">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No pending applications found.</p>
    <?php endif; ?>
</body>
</html>
